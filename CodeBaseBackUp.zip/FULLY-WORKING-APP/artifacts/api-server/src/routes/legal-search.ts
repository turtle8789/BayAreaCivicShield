import { Router, type IRouter } from "express";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const OVERPASS_ENDPOINTS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
  "https://overpass.openstreetmap.ru/api/interpreter",
];

const MAX_RADIUS_M = (50 * 1609.344).toFixed(0); // 50 miles

function buildQuery(lat: number, lon: number): string {
  const c = `${lat},${lon}`;
  // Stick to indexed tag lookups — no regex name matching, no way queries.
  // This keeps the query fast enough for any Overpass mirror.
  return `[out:json][timeout:20];
(
  node["office"="lawyer"](around:${MAX_RADIUS_M},${c});
  node["office"="legal_services"](around:${MAX_RADIUS_M},${c});
  node["office"="legal_aid"](around:${MAX_RADIUS_M},${c});
  node["amenity"="legal_advice"](around:${MAX_RADIUS_M},${c});
  node["amenity"="courthouse"](around:${MAX_RADIUS_M},${c});
  way["office"="lawyer"](around:${MAX_RADIUS_M},${c});
  way["office"="legal_services"](around:${MAX_RADIUS_M},${c});
  way["office"="legal_aid"](around:${MAX_RADIUS_M},${c});
  way["amenity"="courthouse"](around:${MAX_RADIUS_M},${c});
);
out center tags;`;
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3958.8;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

type Category = "lawyer" | "legal_aid" | "courthouse" | "other";

function getCategory(tags: Record<string, string>): Category {
  const o = tags.office;
  const a = tags.amenity;
  if (o === "lawyer") return "lawyer";
  if (o === "legal_services" || o === "legal_aid" || a === "legal_advice") return "legal_aid";
  if (a === "courthouse") return "courthouse";
  return "other";
}

function getTypeInfo(tags: Record<string, string>): { typeKey: string; typeColor: string } {
  const o = tags.office;
  const a = tags.amenity;
  if (o === "lawyer")         return { typeKey: "resources.nearby.type_lawyer",         typeColor: "#9B7EC9" };
  if (o === "legal_services") return { typeKey: "resources.nearby.type_legal_services", typeColor: "#5A9E6F" };
  if (o === "legal_aid")      return { typeKey: "resources.nearby.type_legal_aid",      typeColor: "#4A90D9" };
  if (a === "legal_advice")   return { typeKey: "resources.nearby.type_legal_advice",   typeColor: "#4A90D9" };
  if (a === "courthouse")     return { typeKey: "resources.nearby.type_courthouse",      typeColor: "#C9A050" };
  return { typeKey: "resources.nearby.type_legal_resource", typeColor: "#888" };
}

function getAddress(tags: Record<string, string>): string {
  const num    = tags["addr:housenumber"] || "";
  const street = tags["addr:street"]      || "";
  const city   = tags["addr:city"]        || "";
  const state  = tags["addr:state"]       || "";
  return [num && street ? `${num} ${street}` : street, city, state].filter(Boolean).join(", ");
}

interface OverpassElement {
  id: number;
  type: string;
  lat?: number;
  lon?: number;
  center?: { lat: number; lon: number };
  tags: Record<string, string>;
}

function parseElements(
  elements: OverpassElement[],
  lat: number,
  lon: number,
) {
  const seen = new Set<string>();
  const results = [];

  for (const el of elements) {
    const name = el.tags?.name;
    if (!name) continue;
    const elLat = el.lat ?? el.center?.lat ?? 0;
    const elLon = el.lon ?? el.center?.lon ?? 0;
    if (!elLat && !elLon) continue;

    const key = `${name}|${elLat.toFixed(4)}|${elLon.toFixed(4)}`;
    if (seen.has(key)) continue;
    seen.add(key);

    const dist = haversine(lat, lon, elLat, elLon);
    if (dist > 50) continue;

    const typeInfo = getTypeInfo(el.tags);
    results.push({
      id: `${el.type}-${el.id}`,
      name,
      lat: elLat,
      lon: elLon,
      dist,
      typeKey:   typeInfo.typeKey,
      typeColor: typeInfo.typeColor,
      category:  getCategory(el.tags),
      address:   getAddress(el.tags),
      phone:     el.tags.phone    || el.tags["contact:phone"]   || "",
      website:   el.tags.website  || el.tags["contact:website"] || el.tags.url || "",
    });
  }

  return results.sort((a, b) => a.dist - b.dist);
}

/** GET /api/legal-search?lat=37.77&lon=-122.41
 *  Races all Overpass mirrors in parallel. Returns { results } or 503.
 */
router.get("/legal-search", async (req, res) => {
  const lat = parseFloat(req.query.lat as string);
  const lon = parseFloat(req.query.lon as string);

  if (isNaN(lat) || isNaN(lon)) {
    res.status(400).json({ error: "lat and lon are required numeric query params" });
    return;
  }

  const body = `data=${encodeURIComponent(buildQuery(lat, lon))}`;

  // Race all mirrors simultaneously — first successful response wins.
  let results: ReturnType<typeof parseElements> | null = null;
  try {
    results = await Promise.any(
      OVERPASS_ENDPOINTS.map(async (endpoint) => {
        const ctrl = new AbortController();
        const tid = setTimeout(() => ctrl.abort(), 18_000);
        try {
          const r = await fetch(endpoint, {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "Accept": "application/json, text/javascript, */*",
              "User-Agent": "CivicShieldPro/1.0 (legal-aid-search; civicshield.app)",
            },
            body,
            signal: ctrl.signal,
          });
          if (!r.ok) {
            const txt = await r.text().catch(() => "");
            throw new Error(`HTTP ${r.status}: ${txt.slice(0, 200)}`);
          }
          const json = (await r.json()) as { elements: OverpassElement[] };
          return parseElements(json.elements ?? [], lat, lon);
        } catch (e) {
          logger.warn({ endpoint, err: String(e) }, "Overpass mirror failed");
          throw e;
        } finally {
          clearTimeout(tid);
        }
      }),
    );
  } catch (err) {
    logger.warn({ lat, lon }, "All Overpass mirrors failed");
    res.status(503).json({ error: "overpass_unavailable" });
    return;
  }

  res.json({ results });
});

export default router;
