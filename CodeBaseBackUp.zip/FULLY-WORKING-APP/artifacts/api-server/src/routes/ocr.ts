import { Router, type IRouter } from "express";
import OpenAI from "openai";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const openai = new OpenAI({
  apiKey: process.env["AI_INTEGRATIONS_OPENAI_API_KEY"],
  baseURL: process.env["AI_INTEGRATIONS_OPENAI_BASE_URL"],
});

/** POST /api/ocr
 *  Body: { base64: string; language: string }
 *  Returns: { text: string }
 */
router.post("/ocr", async (req, res) => {
  const { base64, language } = req.body as { base64?: string; language?: string };

  if (!base64) {
    res.status(400).json({ error: "base64 is required" });
    return;
  }

  const lang = language ?? "en";

  // Map ISO codes to human-readable language names for the prompt
  const LANG_NAMES: Record<string, string> = {
    en: "English", es: "Spanish", fr: "French", pt: "Portuguese",
    it: "Italian", de: "German", ru: "Russian", ja: "Japanese",
    ko: "Korean", ar: "Arabic", hi: "Hindi", te: "Telugu",
    ta: "Tamil", bn: "Bengali", id: "Indonesian", ur: "Urdu",
    tr: "Turkish", th: "Thai", vi: "Vietnamese",
    "zh-CN": "Simplified Chinese", "zh-TW": "Traditional Chinese",
  };
  const langName = LANG_NAMES[lang] ?? lang;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: lang === "en"
                ? `Extract all text from this document image exactly as it appears. Preserve line breaks and formatting. Return only the extracted text with no commentary.`
                : `Extract all text from this document image, then translate everything into ${langName}. Return only the ${langName} translation — do not include the original text. Preserve the document's structure and line breaks.`,
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64}`,
                detail: "high",
              },
            },
          ],
        },
      ],
      max_tokens: 4096,
    });

    const text = response.choices[0]?.message?.content?.trim() ?? "";
    res.json({ text });
  } catch (err) {
    logger.error({ err, lang }, "OCR failed");
    res.status(500).json({ error: "OCR failed" });
  }
});

export default router;
