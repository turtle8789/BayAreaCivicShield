import { Router, type IRouter } from "express";
import healthRouter from "./health";
import legalSearchRouter from "./legal-search";
import ocrRouter from "./ocr";
import ratingsRouter from "./ratings";

const router: IRouter = Router();

router.use(healthRouter);
router.use(legalSearchRouter);
router.use(ocrRouter);
router.use(ratingsRouter);

export default router;
