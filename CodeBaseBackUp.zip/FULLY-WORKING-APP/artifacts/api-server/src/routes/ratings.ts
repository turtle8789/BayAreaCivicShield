/**
 * Community ratings for legal search results.
 * Stores ratings in data/ratings.json (persisted across restarts).
 *
 * GET  /api/ratings?ids=id1,id2,id3  → { [id]: { avg, count } }
 * POST /api/ratings                  → { resourceId, rating: 1-5 } → { avg, count }
 */
import { Router, type IRouter } from "express";
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "fs";
import { join } from "path";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// ─── File-backed persistence ──────────────────────────────────────────────────

const DATA_DIR  = join(process.cwd(), "data");
const DATA_FILE = join(DATA_DIR, "ratings.json");

interface Entry { total: number; count: number }
type Store = Record<string, Entry>;

function load(): Store {
  try {
    if (!existsSync(DATA_FILE)) return {};
    return JSON.parse(readFileSync(DATA_FILE, "utf-8")) as Store;
  } catch {
    return {};
  }
}

function save(s: Store) {
  try {
    if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(DATA_FILE, JSON.stringify(s, null, 2), "utf-8");
  } catch (e) {
    logger.error({ err: String(e) }, "Failed to persist ratings");
  }
}

let store: Store = load();

function avg(e: Entry) {
  return Math.round((e.total / e.count) * 10) / 10;
}

// ─── GET /api/ratings?ids=... ─────────────────────────────────────────────────

router.get("/ratings", (req, res) => {
  const ids = String(req.query.ids ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  const out: Record<string, { avg: number; count: number }> = {};
  for (const id of ids) {
    if (store[id]) out[id] = { avg: avg(store[id]), count: store[id].count };
  }
  res.json(out);
});

// ─── POST /api/ratings ────────────────────────────────────────────────────────

router.post("/ratings", (req, res) => {
  const { resourceId, rating } = req.body as {
    resourceId?: string;
    rating?: number;
  };

  if (!resourceId || typeof rating !== "number" || rating < 1 || rating > 5) {
    res.status(400).json({ error: "resourceId and rating (1-5) are required" });
    return;
  }

  const r = Math.round(rating);
  if (!store[resourceId]) store[resourceId] = { total: 0, count: 0 };
  store[resourceId].total += r;
  store[resourceId].count += 1;
  save(store);

  const entry = store[resourceId];
  res.json({ avg: avg(entry), count: entry.count });
});

export default router;
