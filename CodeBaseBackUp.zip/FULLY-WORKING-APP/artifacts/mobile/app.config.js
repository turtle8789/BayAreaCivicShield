// app.config.js — extends app.json with runtime env vars
const base = require('./app.json');

const devDomain = process.env.REPLIT_DEV_DOMAIN ?? '';

module.exports = {
  ...base.expo,
  extra: {
    ...(base.expo.extra ?? {}),
    // API server base URL, available in app via Constants.expoConfig.extra.apiBaseUrl
    apiBaseUrl: devDomain ? `https://${devDomain}` : '',
  },
};
