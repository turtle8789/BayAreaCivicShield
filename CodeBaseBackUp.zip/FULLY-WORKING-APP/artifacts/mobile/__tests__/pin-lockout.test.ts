/**
 * Unit tests for the PIN brute-force lockout state machine.
 *
 * Covers the four end-to-end scenarios from the task spec:
 *   1. 5 wrong PINs → lockout UI state appears
 *   2. Force-quit and reopen mid-lockout → lockout still active with correct remaining time
 *   3. Lockout expires naturally → counter resets, numpad re-enables
 *   4. Correct PIN after lockout expires → attempt counter fully cleared
 *
 * Plus edge-case guards:
 *   - Corrupted / non-finite stored values fail open (not fail locked)
 *   - Null / missing stored values are treated as 0 / no lockout
 *   - Partial storage (attempts stored but no expiry) is preserved correctly
 */

import {
  MAX_ATTEMPTS,
  LOCKOUT_SECONDS,
  parseLockoutState,
  computeAttemptResult,
  isValidPin,
} from '../utils/pinLockout';

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const NOW = new Date('2026-08-02T12:00:00.000Z').getTime();
const LOCKOUT_MS = LOCKOUT_SECONDS * 1000;

// ─── isValidPin ───────────────────────────────────────────────────────────────

describe('isValidPin – valid PINs', () => {
  it('accepts a 4-digit string', () => {
    expect(isValidPin('1234')).toBe(true);
    expect(isValidPin('0000')).toBe(true);
    expect(isValidPin('9999')).toBe(true);
  });
});

describe('isValidPin – corrupt / invalid PINs (must never silently lock the user out)', () => {
  it('rejects an empty string', () => {
    expect(isValidPin('')).toBe(false);
  });

  it('rejects a PIN shorter than 4 digits', () => {
    expect(isValidPin('123')).toBe(false);
    expect(isValidPin('1')).toBe(false);
  });

  it('rejects a PIN longer than 4 digits', () => {
    expect(isValidPin('12345')).toBe(false);
  });

  it('rejects non-numeric strings', () => {
    expect(isValidPin('abcd')).toBe(false);
    expect(isValidPin('12ab')).toBe(false);
    expect(isValidPin('####')).toBe(false);
  });

  it('rejects null', () => {
    expect(isValidPin(null)).toBe(false);
  });

  it('rejects undefined', () => {
    expect(isValidPin(undefined)).toBe(false);
  });

  it('rejects numbers (must be a string)', () => {
    expect(isValidPin(1234)).toBe(false);
  });

  it('corrupt empty PIN cannot produce a matching entry — recovery path must be shown', () => {
    // This is the key regression guard for task 77:
    // If the stored PIN is empty or corrupt, isValidPin must detect it so the
    // component shows recovery instead of letting the user attempt PINs forever.
    const corruptCases: unknown[] = ['', 'abc', '123', '12345', null, undefined];
    for (const bad of corruptCases) {
      expect(isValidPin(bad)).toBe(false);
    }
    // Any 4-digit attempt will never equal an invalid pin — no path to success exists
    const validAttempt = '1234';
    for (const bad of corruptCases) {
      expect(validAttempt === bad).toBe(false);
    }
  });
});

// ─── Layout gating: corrupt/empty PIN must not bypass App Lock ────────────────
//
// _layout.tsx gates PinLockScreen on `appLockEnabled && !unlocked` (NOT on
// `appLockEnabled && appPin`).  These tests document the invariant so any
// future regression to the old `&& appPin` form is caught immediately.

describe('layout gating: App Lock is enforced regardless of PIN content', () => {
  // Pure representation of the layout gate condition:
  //   showLockScreen = appLockEnabled && !unlocked
  // (appPin is intentionally excluded)
  const shouldShowLockScreen = (appLockEnabled: boolean, unlocked: boolean) =>
    appLockEnabled && !unlocked;

  it('shows lock screen when App Lock is enabled with a valid PIN', () => {
    expect(shouldShowLockScreen(true, false)).toBe(true);
  });

  it('shows lock screen when App Lock is enabled with an EMPTY PIN (corrupt case)', () => {
    // If the gate were `appLockEnabled && appPin && !unlocked`, an empty appPin
    // would make this false — silently bypassing App Lock.
    // The gate must NOT include `appPin` as a condition.
    const appLockEnabled = true;
    const appPin = ''; // corrupt — empty string
    const unlocked = false;

    // Correct gate: appLockEnabled && !unlocked (ignores appPin)
    expect(shouldShowLockScreen(appLockEnabled, unlocked)).toBe(true);

    // Recovery card condition: isValidPin(appPin) === false → recovery shown
    expect(isValidPin(appPin)).toBe(false);
  });

  it('does NOT show lock screen when unlocked is true, even with a valid PIN', () => {
    expect(shouldShowLockScreen(true, true)).toBe(false);
  });

  it('does NOT show lock screen when App Lock is disabled', () => {
    expect(shouldShowLockScreen(false, false)).toBe(false);
  });

  it('empty PIN always triggers the recovery path (isValidPin = false)', () => {
    const corruptPins = ['', 'abc', '12', '12345', '12ab'];
    for (const pin of corruptPins) {
      expect(isValidPin(pin)).toBe(false);
    }
  });

  it('valid PIN does NOT trigger recovery (isValidPin = true)', () => {
    expect(isValidPin('1234')).toBe(true);
    expect(isValidPin('0000')).toBe(true);
  });
});

// ─── parseLockoutState ────────────────────────────────────────────────────────

describe('parseLockoutState – fresh install (nothing in storage)', () => {
  it('returns zero attempts and no lockout when storage is empty', () => {
    const result = parseLockoutState(null, null, NOW);
    expect(result.attempts).toBe(0);
    expect(result.lockedUntil).toBeNull();
    expect(result.shouldClearStorage).toBe(false);
  });
});

describe('parseLockoutState – active lockout (force-quit scenario)', () => {
  it('restores an active lockout with the stored expiry', () => {
    const expiry = NOW + LOCKOUT_MS;
    const result = parseLockoutState(
      String(MAX_ATTEMPTS),
      String(expiry),
      NOW,
    );
    expect(result.attempts).toBe(MAX_ATTEMPTS);
    expect(result.lockedUntil).toBe(expiry);
    expect(result.shouldClearStorage).toBe(false);
  });

  it('calculates correct remaining time from the restored expiry', () => {
    const expiry = NOW + LOCKOUT_MS;
    const result = parseLockoutState(String(MAX_ATTEMPTS), String(expiry), NOW);
    const remaining = Math.ceil((result.lockedUntil! - NOW) / 1000);
    expect(remaining).toBe(LOCKOUT_SECONDS);
  });

  it('still reports locked when only 1 second remains', () => {
    const expiry = NOW + 1000;
    const result = parseLockoutState(String(MAX_ATTEMPTS), String(expiry), NOW);
    expect(result.lockedUntil).toBe(expiry);
    expect(result.lockedUntil! > NOW).toBe(true);
  });
});

describe('parseLockoutState – expired lockout (reopened after lockout window)', () => {
  it('returns zero attempts and null lockedUntil when expiry has passed', () => {
    const expiredAt = NOW - 1; // 1 ms in the past
    const result = parseLockoutState(String(MAX_ATTEMPTS), String(expiredAt), NOW);
    expect(result.attempts).toBe(0);
    expect(result.lockedUntil).toBeNull();
  });

  it('flags shouldClearStorage so the caller wipes stale AsyncStorage keys', () => {
    const expiredAt = NOW - LOCKOUT_MS; // expired a full lockout period ago
    const result = parseLockoutState(String(MAX_ATTEMPTS), String(expiredAt), NOW);
    expect(result.shouldClearStorage).toBe(true);
  });

  it('resets attempts to 0 (not MAX_ATTEMPTS) — prevents immediate re-lockout', () => {
    // This is the critical regression guard: before the fix, the stale MAX_ATTEMPTS
    // value from storage was kept, so the very next wrong PIN triggered a new lockout.
    const expiredAt = NOW - 1;
    const result = parseLockoutState(String(MAX_ATTEMPTS), String(expiredAt), NOW);
    expect(result.attempts).toBe(0);

    // Confirm: after reset, the first wrong PIN does NOT re-lock
    const attempt = computeAttemptResult(result.attempts, NOW);
    expect(attempt.lockedUntilExpiry).toBeNull();
  });

  it('treats a lockout that expired exactly at now as expired', () => {
    // expiry === now is a boundary: the lockout is not active
    const result = parseLockoutState(String(MAX_ATTEMPTS), String(NOW), NOW);
    expect(result.lockedUntil).toBeNull();
    expect(result.shouldClearStorage).toBe(true);
  });
});

describe('parseLockoutState – partial storage (attempt count without expiry)', () => {
  it('restores the attempt count when there is no expiry stored', () => {
    // User had 3 wrong attempts but did not yet trigger a lockout
    const result = parseLockoutState('3', null, NOW);
    expect(result.attempts).toBe(3);
    expect(result.lockedUntil).toBeNull();
    expect(result.shouldClearStorage).toBe(false);
  });

  it('returns 0 attempts when both keys are null', () => {
    const result = parseLockoutState(null, null, NOW);
    expect(result.attempts).toBe(0);
  });
});

describe('parseLockoutState – corrupted storage (fail-open guard)', () => {
  it('treats a non-numeric attempt string as 0', () => {
    const result = parseLockoutState('corrupted', null, NOW);
    expect(result.attempts).toBe(0);
  });

  it('treats a non-numeric expiry string as no lockout', () => {
    const result = parseLockoutState('5', 'corrupted', NOW);
    expect(result.lockedUntil).toBeNull();
    expect(result.attempts).toBe(5); // count survives even if expiry is bad
  });

  it('treats NaN attempt string as 0', () => {
    const result = parseLockoutState('NaN', null, NOW);
    expect(result.attempts).toBe(0);
  });

  it('treats NaN expiry string as no lockout', () => {
    const result = parseLockoutState('5', 'NaN', NOW);
    expect(result.lockedUntil).toBeNull();
  });

  it('treats Infinity attempt string as 0 (non-finite guard)', () => {
    const result = parseLockoutState('Infinity', null, NOW);
    expect(result.attempts).toBe(0);
  });

  it('treats negative expiry (impossible timestamp) as no lockout', () => {
    const result = parseLockoutState('5', String(-1), NOW);
    // -1 < now, so treated as expired
    expect(result.lockedUntil).toBeNull();
    expect(result.shouldClearStorage).toBe(true);
  });
});

// ─── computeAttemptResult ─────────────────────────────────────────────────────

describe('computeAttemptResult – progress toward lockout', () => {
  it('increments the counter without locking on the first wrong PIN', () => {
    const result = computeAttemptResult(0, NOW);
    expect(result.newAttempts).toBe(1);
    expect(result.lockedUntilExpiry).toBeNull();
  });

  it('does not lock until exactly MAX_ATTEMPTS wrong PINs', () => {
    // Attempts 1 through MAX_ATTEMPTS - 1 should not lock
    for (let prior = 0; prior < MAX_ATTEMPTS - 1; prior++) {
      const result = computeAttemptResult(prior, NOW);
      expect(result.lockedUntilExpiry).toBeNull();
    }
  });

  it('returns a lockout expiry exactly at MAX_ATTEMPTS failures', () => {
    const result = computeAttemptResult(MAX_ATTEMPTS - 1, NOW);
    expect(result.newAttempts).toBe(MAX_ATTEMPTS);
    expect(result.lockedUntilExpiry).not.toBeNull();
  });

  it('sets the expiry to now + LOCKOUT_SECONDS', () => {
    const result = computeAttemptResult(MAX_ATTEMPTS - 1, NOW);
    expect(result.lockedUntilExpiry).toBe(NOW + LOCKOUT_SECONDS * 1000);
  });

  it('also locks on any count >= MAX_ATTEMPTS (overflow guard)', () => {
    const result = computeAttemptResult(MAX_ATTEMPTS, NOW);
    expect(result.lockedUntilExpiry).not.toBeNull();
    expect(result.newAttempts).toBe(MAX_ATTEMPTS + 1);
  });
});

// ─── End-to-end scenario: force-quit mid-lockout ──────────────────────────────

describe('end-to-end: force-quit and reopen mid-lockout', () => {
  it('reproduces the full lockout + force-quit + reopen sequence', () => {
    // Step 1 — user enters 5 wrong PINs; final attempt triggers lockout
    let attempts = 0;
    let expiry: number | null = null;

    for (let i = 0; i < MAX_ATTEMPTS; i++) {
      const result = computeAttemptResult(attempts, NOW);
      attempts = result.newAttempts;
      if (result.lockedUntilExpiry !== null) {
        expiry = result.lockedUntilExpiry;
      }
    }

    expect(attempts).toBe(MAX_ATTEMPTS);
    expect(expiry).toBe(NOW + LOCKOUT_MS);

    // Step 2 — force-quit 10 seconds later; storage still holds the expiry
    const reopenTime = NOW + 10_000;

    // Step 3 — app reopens; hydrate from storage
    const hydrated = parseLockoutState(String(attempts), String(expiry!), reopenTime);

    expect(hydrated.lockedUntil).toBe(expiry); // lockout still active
    expect(hydrated.shouldClearStorage).toBe(false);

    // Step 4 — remaining time should be ~20 s (30 - 10)
    const remaining = Math.ceil((hydrated.lockedUntil! - reopenTime) / 1000);
    expect(remaining).toBe(LOCKOUT_SECONDS - 10);
  });
});

// ─── End-to-end scenario: lockout expires naturally ───────────────────────────

describe('end-to-end: lockout expiry clears the counter', () => {
  it('countdown reaches zero and attempt state resets', () => {
    // Simulate the countdown ticker reaching 0
    const expiry = NOW + LOCKOUT_MS;

    // At NOW the lockout is active
    expect(expiry > NOW).toBe(true);

    // At NOW + LOCKOUT_MS the lockout has expired
    const afterExpiry = NOW + LOCKOUT_MS;
    const remaining = Math.ceil((expiry - afterExpiry) / 1000);
    expect(remaining).toBeLessThanOrEqual(0);

    // parseLockoutState after expiry must return clean state
    const hydrated = parseLockoutState(String(MAX_ATTEMPTS), String(expiry), afterExpiry);
    expect(hydrated.lockedUntil).toBeNull();
    expect(hydrated.attempts).toBe(0);
    expect(hydrated.shouldClearStorage).toBe(true);
  });
});

// ─── End-to-end scenario: correct PIN after lockout expires ───────────────────

describe('end-to-end: correct PIN after lockout expires clears all state', () => {
  it('after a successful PIN, no lockout data remains in storage (simulated)', () => {
    // The component calls AsyncStorage.multiRemove([KEY_ATTEMPTS, KEY_LOCKED_UNTIL])
    // on success.  We can prove correctness by showing that if we re-hydrate from
    // empty storage after that remove, we get a clean zero state.
    const afterSuccess = parseLockoutState(null, null, NOW);

    expect(afterSuccess.attempts).toBe(0);
    expect(afterSuccess.lockedUntil).toBeNull();
    expect(afterSuccess.shouldClearStorage).toBe(false);
  });

  it('entering a correct PIN when attempts > 0 but no lockout leaves clean state', () => {
    // User had 3 wrong PINs, then entered the correct one — storage should be wiped
    const afterSuccess = parseLockoutState(null, null, NOW);
    expect(afterSuccess.attempts).toBe(0);
  });
});

// ─── App Lock toggle: stale lockout state must not survive disable/re-enable ──
//
// setAppLock() calls AsyncStorage.multiRemove([KEY_ATTEMPTS, KEY_LOCKED_UNTIL])
// on every call — whether enabling or disabling App Lock.  These tests document
// what the hydration layer must see after that remove so the PIN counter always
// starts from zero on re-enable.

describe('App Lock toggle: no stale lockout state survives disable/re-enable', () => {
  it('hydrating from empty storage (post-disable) returns zero attempts and no lockout', () => {
    // Simulates the state after setAppLock(false, '') clears both keys
    const state = parseLockoutState(null, null, NOW);
    expect(state.attempts).toBe(0);
    expect(state.lockedUntil).toBeNull();
    expect(state.shouldClearStorage).toBe(false);
  });

  it('after disable/re-enable, entering wrong PINs starts counter from zero', () => {
    // Storage was wiped by setAppLock — first wrong PIN increments from 0 to 1
    const clean = parseLockoutState(null, null, NOW);
    const first = computeAttemptResult(clean.attempts, NOW);
    expect(first.newAttempts).toBe(1);
    expect(first.lockedUntilExpiry).toBeNull(); // no lockout on first attempt
  });

  it('after toggle, MAX_ATTEMPTS-1 wrong PINs still do not trigger a lockout', () => {
    // Regression guard: stale MAX_ATTEMPTS value from an old PIN session must not
    // survive into the new session and cause an immediate lockout on first wrong PIN
    const clean = parseLockoutState(null, null, NOW);
    let attempts = clean.attempts; // 0
    let expiry: number | null = null;
    for (let i = 0; i < MAX_ATTEMPTS - 1; i++) {
      const result = computeAttemptResult(attempts, NOW);
      attempts = result.newAttempts;
      expiry = result.lockedUntilExpiry;
    }
    expect(expiry).toBeNull(); // should NOT be locked yet
    expect(attempts).toBe(MAX_ATTEMPTS - 1);
  });

  it('hydrating from partially-cleared storage (attempts left, no expiry) after re-enable starts fresh', () => {
    // If only KEY_LOCKED_UNTIL was removed but KEY_ATTEMPTS somehow remained,
    // parseLockoutState should treat it as a clean pre-lockout count — not a lockout.
    // setAppLock always removes BOTH keys so this is a belt-and-suspenders guard.
    const state = parseLockoutState(null, null, NOW);
    expect(state.lockedUntil).toBeNull();
    // Confirm first wrong PIN on the clean state does NOT trigger an immediate lockout
    const result = computeAttemptResult(state.attempts, NOW);
    expect(result.lockedUntilExpiry).toBeNull();
  });

  it('a full lockout active before toggle is gone after storage is cleared', () => {
    // Simulate: user hit 5 wrong PINs → lockout in storage.
    // Then setAppLock(false, '') fires → both keys removed.
    // Re-enable: parseLockoutState on empty storage must see no lockout.
    const expiry = NOW + LOCKOUT_MS;
    // Confirm an active lockout exists before the toggle
    const before = parseLockoutState(String(MAX_ATTEMPTS), String(expiry), NOW);
    expect(before.lockedUntil).not.toBeNull();

    // After toggle: storage is wiped (null, null)
    const after = parseLockoutState(null, null, NOW);
    expect(after.lockedUntil).toBeNull();
    expect(after.attempts).toBe(0);
    expect(after.shouldClearStorage).toBe(false);
  });
});
