/**
 * Legal Aid Near Me — server-side Overpass search with type + radius filters.
 */
import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import Constants from 'expo-constants';
import { Feather } from '@expo/vector-icons';
import { StarDisplay, TappableStars } from '@/components/StarDisplay';
import * as Haptics from 'expo-haptics';
import * as Location from 'expo-location';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LEGAL_RESOURCES } from '@/constants/legal-resources';
import { useColors } from '@/hooks/useColors';
import { useRTL } from '@/hooks/useRTL';
import { useT } from '@/hooks/useTranslation';

// ─── Types ────────────────────────────────────────────────────────────────────

type Category = 'lawyer' | 'legal_aid' | 'courthouse' | 'other';

interface LiveResult {
  id: string;
  name: string;
  lat: number;
  lon: number;
  dist: number;
  typeKey: string;
  typeColor: string;
  category: Category;
  address: string;
  phone: string;
  website: string;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3958.8;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function getApiBase(): string {
  return (Constants.expoConfig?.extra as { apiBaseUrl?: string } | undefined)?.apiBaseUrl ?? '';
}

async function openGoogleMaps(lat: number, lon: number, name: string) {
  const query  = encodeURIComponent(name);
  const coords = `${lat},${lon}`;
  const googleUrl = `https://maps.google.com/?q=${query}&ll=${coords}`;
  if (Platform.OS === 'ios') {
    const appleUrl = `maps:?q=${query}&ll=${coords}`;
    if (await Linking.canOpenURL(appleUrl)) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      await Linking.openURL(appleUrl);
      return;
    }
  }
  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  await Linking.openURL(googleUrl);
}

// ─── API search (server-side Overpass) ───────────────────────────────────────

async function searchLegalNearby(lat: number, lon: number): Promise<{ results: LiveResult[]; curated: boolean }> {
  const apiBase = getApiBase();
  if (apiBase) {
    try {
      const res = await fetch(`${apiBase}/api/legal-search?lat=${lat}&lon=${lon}`);
      if (res.ok) {
        const data = (await res.json()) as { results: LiveResult[] };
        return { results: data.results ?? [], curated: false };
      }
      // 503 = all mirrors failed → fall through to curated
    } catch {
      // network error → fall through
    }
  }

  // Curated fallback: LEGAL_RESOURCES sorted by distance
  const fallback: LiveResult[] = LEGAL_RESOURCES
    .map(r => ({
      id: r.id,
      name: r.name,
      lat: r.lat,
      lon: r.lon,
      dist: haversine(lat, lon, r.lat, r.lon),
      typeKey: 'resources.nearby.type_legal_aid' as string,
      typeColor: '#4A90D9',
      category: 'legal_aid' as Category,
      address: r.address,
      phone: r.phone,
      website: r.website.startsWith('http') ? r.website : `https://${r.website}`,
    }))
    .sort((a, b) => a.dist - b.dist);

  return { results: fallback, curated: true };
}

// ─── Geocoding ────────────────────────────────────────────────────────────────

async function geocodeAddress(q: string): Promise<{ lat: number; lon: number; name: string } | null> {
  // 1. Native device geocoding
  try {
    const r = await Location.geocodeAsync(q);
    if (r.length > 0) return { lat: r[0].latitude, lon: r[0].longitude, name: q };
  } catch {
    // fall through
  }

  // 2. Nominatim mirrors
  for (const base of ['https://nominatim.openstreetmap.org', 'https://nominatim.geocoding.ai']) {
    try {
      const ctrl = new AbortController();
      const tid  = setTimeout(() => ctrl.abort(), 10_000);
      let data: Array<{ lat: string; lon: string; display_name: string }> = [];
      try {
        const res = await fetch(
          `${base}/search?q=${encodeURIComponent(q)}&format=json&limit=1`,
          { signal: ctrl.signal, headers: { 'User-Agent': 'CivicShieldPro/1.0' } },
        );
        data = await res.json();
      } finally {
        clearTimeout(tid);
      }
      if (data?.length) {
        return {
          lat: parseFloat(data[0].lat),
          lon: parseFloat(data[0].lon),
          name: data[0].display_name.split(',').slice(0, 2).join(','),
        };
      }
    } catch {
      // try next
    }
  }
  return null;
}

// ─── Type filter config ───────────────────────────────────────────────────────

type TypeFilter = 'all' | Category;

const TYPE_FILTERS: Array<{ key: TypeFilter; labelKey: string; color: string }> = [
  { key: 'all',        labelKey: 'resources.filter_all',               color: '#888'    },
  { key: 'lawyer',     labelKey: 'resources.nearby.type_lawyer',       color: '#9B7EC9' },
  { key: 'legal_aid',  labelKey: 'resources.nearby.type_legal_aid',    color: '#4A90D9' },
  { key: 'courthouse', labelKey: 'resources.nearby.type_courthouse',   color: '#C9A050' },
];

// ─── fetchRatings (non-blocking) ─────────────────────────────────────────────

async function fetchRatings(
  results: LiveResult[],
  setRatings: (r: Record<string, { avg: number; count: number }>) => void,
) {
  const ids = results.map((r) => r.id).join(',');
  if (!ids) return;
  const apiBase = getApiBase();
  if (!apiBase) return;
  try {
    const res = await fetch(`${apiBase}/api/ratings?ids=${encodeURIComponent(ids)}`);
    if (res.ok) {
      const data = (await res.json()) as Record<string, { avg: number; count: number }>;
      setRatings(data);
    }
  } catch {
    // ratings are decorative — never surface an error
  }
}

// ─── RatingModal ──────────────────────────────────────────────────────────────

function RatingModal({
  item,
  onClose,
  onSubmit,
}: {
  item: LiveResult;
  onClose: () => void;
  onSubmit: (id: string, rating: number) => void;
}) {
  const colors = useColors();
  const { t }  = useT();
  const [selected, setSelected] = React.useState(0);

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      <Pressable
        style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'flex-end' }}
        onPress={onClose}>
        <View
          style={{ backgroundColor: colors.card, borderTopLeftRadius: 24, borderTopRightRadius: 24,
            padding: 24, paddingBottom: 40, gap: 16 }}
          // stop propagation so tapping the card doesn't close modal
          onStartShouldSetResponder={() => true}>
          <Text style={{ fontSize: 17, fontFamily: 'Inter_700Bold', color: colors.foreground }}>
            {t('ratings.modal_title')}
          </Text>
          <Text style={{ fontSize: 13, fontFamily: 'Inter_400Regular', color: colors.mutedForeground }}>
            {item.name}
          </Text>
          <TappableStars selected={selected} onSelect={setSelected} size={38} />
          <Pressable
            disabled={selected === 0}
            onPress={() => onSubmit(item.id, selected)}
            style={{ backgroundColor: selected > 0 ? colors.primary : colors.muted,
              borderRadius: 14, paddingVertical: 14, alignItems: 'center',
              opacity: selected > 0 ? 1 : 0.45 }}>
            <Text style={{ fontSize: 15, fontFamily: 'Inter_600SemiBold',
              color: selected > 0 ? '#FFFFFF' : colors.mutedForeground }}>
              {t('ratings.submit')}
            </Text>
          </Pressable>
        </View>
      </Pressable>
    </Modal>
  );
}

// ─── LiveResultCard ───────────────────────────────────────────────────────────

function LiveResultCard({
  item,
  rowDir,
  ratingData,
  userRating,
  onRate,
}: {
  item: LiveResult;
  rowDir: 'row' | 'row-reverse';
  ratingData?: { avg: number; count: number };
  userRating?: number;
  onRate: (item: LiveResult) => void;
}) {
  const colors = useColors();
  const { t }  = useT();

  return (
    <View style={{ backgroundColor: colors.card, borderRadius: colors.radius, borderWidth: 1,
      borderColor: colors.border, padding: 14, marginBottom: 10 }}>
      {/* Type badge + distance */}
      <View style={{ flexDirection: rowDir, alignItems: 'center', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
        <View style={{ paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20,
          backgroundColor: item.typeColor + '20' }}>
          <Text style={{ fontSize: 11, fontFamily: 'Inter_600SemiBold', color: item.typeColor }}>
            {t(item.typeKey as any)}
          </Text>
        </View>
        <Text style={{ fontSize: 11, fontFamily: 'Inter_500Medium', color: '#5A9E6F',
          backgroundColor: '#5A9E6F18', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 20 }}>
          {item.dist < 0.2
            ? `${Math.round(item.dist * 5280)} ${t('resources.nearby.ft_away')}`
            : `${item.dist < 10 ? item.dist.toFixed(1) : Math.round(item.dist)} ${t('resources.nearby.mi_away')}`}
        </Text>
      </View>
      <Text style={{ fontSize: 15, fontFamily: 'Inter_600SemiBold', color: colors.foreground, marginBottom: 4 }}>
        {item.name}
      </Text>

      {/* ── Star rating row ── */}
      <View style={{ flexDirection: rowDir, alignItems: 'center', gap: 6, marginBottom: 8, flexWrap: 'wrap' }}>
        {ratingData ? (
          <>
            <StarDisplay rating={ratingData.avg} size={13} />
            <Text style={{ fontSize: 11, fontFamily: 'Inter_500Medium', color: colors.mutedForeground }}>
              {ratingData.avg.toFixed(1)} ({ratingData.count} {ratingData.count === 1 ? t('ratings.review') : t('ratings.reviews')})
            </Text>
          </>
        ) : (
          <Text style={{ fontSize: 11, fontFamily: 'Inter_400Regular', color: colors.mutedForeground }}>
            {t('ratings.no_ratings')}
          </Text>
        )}
        {userRating ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3, marginLeft: 'auto' as any }}>
            <Feather name="check-circle" size={11} color="#5A9E6F" />
            <Text style={{ fontSize: 11, fontFamily: 'Inter_500Medium', color: '#5A9E6F' }}>
              {t('ratings.you_rated')} {userRating}★
            </Text>
          </View>
        ) : (
          <Pressable onPress={() => onRate(item)} hitSlop={8} style={{ marginLeft: 'auto' as any }}>
            <Text style={{ fontSize: 11, fontFamily: 'Inter_500Medium', color: colors.primary }}>
              {t('ratings.rate_this')}
            </Text>
          </Pressable>
        )}
      </View>

      {item.address ? (
        <Text style={{ fontSize: 12, fontFamily: 'Inter_400Regular', color: colors.mutedForeground, marginBottom: 8 }}>
          📍 {item.address}
        </Text>
      ) : null}
      <View style={{ flexDirection: rowDir, gap: 8, flexWrap: 'wrap' }}>
        {item.phone ? (
          <Pressable
            style={{ flexDirection: rowDir, alignItems: 'center', gap: 5, backgroundColor: colors.primary + '14',
              borderRadius: 10, paddingVertical: 8, paddingHorizontal: 12 }}
            onPress={() => Linking.openURL(`tel:${item.phone.replace(/\D/g, '')}`)}
            accessibilityRole="button">
            <Feather name="phone" size={13} color={colors.primary} />
            <Text style={{ fontSize: 12, fontFamily: 'Inter_500Medium', color: colors.primary }}>
              {t('common.call')}
            </Text>
          </Pressable>
        ) : null}
        {item.website ? (
          <Pressable
            style={{ flexDirection: rowDir, alignItems: 'center', gap: 5, backgroundColor: colors.muted,
              borderRadius: 10, paddingVertical: 8, paddingHorizontal: 12 }}
            onPress={() => Linking.openURL(item.website.startsWith('http') ? item.website : `https://${item.website}`)}
            accessibilityRole="button">
            <Feather name="globe" size={13} color={colors.mutedForeground} />
            <Text style={{ fontSize: 12, fontFamily: 'Inter_500Medium', color: colors.mutedForeground }}>
              {t('common.website')}
            </Text>
          </Pressable>
        ) : null}
        <Pressable
          style={{ flexDirection: rowDir, alignItems: 'center', gap: 5, backgroundColor: '#5A9E6F14',
            borderRadius: 10, paddingVertical: 8, paddingHorizontal: 12 }}
          onPress={() => openGoogleMaps(item.lat, item.lon, item.name)}
          accessibilityRole="button">
          <Feather name="map-pin" size={13} color="#5A9E6F" />
          <Text style={{ fontSize: 12, fontFamily: 'Inter_500Medium', color: '#5A9E6F' }}>
            {t('resources.nearby.maps')}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

const RADIUS_CHIPS = [1, 5, 10, 25, 50] as const;

export default function ResourcesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { t }  = useT();
  const { rowDir } = useRTL();
  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  const [loading, setLoading]         = useState(false);
  const [locationName, setLocationName] = useState('');
  const [manualInput, setManualInput] = useState('');
  const [allResults, setAllResults]   = useState<LiveResult[]>([]);
  const [searched, setSearched]       = useState(false);
  const [radiusMiles, setRadiusMiles] = useState<number>(25);
  const [activeType, setActiveType]   = useState<TypeFilter>('all');
  const [isCurated, setIsCurated]     = useState(false);
  const [userLat, setUserLat]         = useState<number | null>(null);
  const [userLon, setUserLon]         = useState<number | null>(null);
  const [ratings, setRatings]         = useState<Record<string, { avg: number; count: number }>>({});
  const [userRatings, setUserRatings] = useState<Record<string, number>>({});
  const [ratingTarget, setRatingTarget] = useState<LiveResult | null>(null);

  const runSearch = async (lat: number, lon: number, name: string) => {
    setLoading(true);
    setIsCurated(false);
    setActiveType('all');
    setUserLat(lat);
    setUserLon(lon);
    setLocationName(name);
    try {
      const { results, curated } = await searchLegalNearby(lat, lon);
      setAllResults(results);
      setIsCurated(curated);
      setSearched(true);
      setRatings({});
      setUserRatings({});
      if (results.length > 0) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        fetchRatings(results, setRatings); // non-blocking
      }
    } catch {
      Alert.alert(t('resources.error_title'), t('resources.nearby.error'));
    } finally {
      setLoading(false);
    }
  };

  const useMyLocation = async () => {
    try {
      setLoading(true);
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(t('resources.perm_denied_title'), t('resources.perm_denied'));
        setLoading(false);
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      await runSearch(loc.coords.latitude, loc.coords.longitude, t('resources.your_location'));
    } catch {
      Alert.alert(t('resources.error_title'), t('resources.location_error'));
      setLoading(false);
    }
  };

  const searchByAddress = async () => {
    const q = manualInput.trim();
    if (!q) return;
    setLoading(true);
    try {
      const geo = await geocodeAddress(q);
      if (!geo) {
        Alert.alert(t('resources.not_found'), t('resources.nearby.geocode_not_found').replace('{query}', q));
        setLoading(false);
        return;
      }
      await runSearch(geo.lat, geo.lon, geo.name);
    } catch {
      Alert.alert(t('resources.error_title'), t('resources.geocode_error'));
      setLoading(false);
    }
  };

  // Apply radius first, then category type filter
  const withinRadius = allResults.filter(r => r.dist <= radiusMiles);
  const filtered = activeType === 'all'
    ? withinRadius
    : withinRadius.filter(r => r.category === activeType);

  const callEmergency = async () => {
    const url = 'tel:911';
    const ok = await Linking.canOpenURL(url);
    if (ok) { Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); await Linking.openURL(url); }
    else Alert.alert(t('resources.emergency_title'), t('resources.emergency_msg'));
  };

  const styles = StyleSheet.create({
    container:    { flex: 1, backgroundColor: colors.background },
    header:       { paddingTop: topPad + 12, paddingHorizontal: 20, paddingBottom: 14,
                    borderBottomWidth: 1, borderBottomColor: colors.border },
    headerTitle:  { fontSize: 22, fontFamily: 'Inter_700Bold', color: colors.foreground },
    headerSub:    { fontSize: 13, fontFamily: 'Inter_400Regular', color: colors.mutedForeground, marginTop: 2 },
    scroll:       { flex: 1 },
    scrollContent:{ padding: 16, paddingBottom: Platform.OS === 'web' ? 34 : 120, flexGrow: 1 },
    emergencyCard:{ backgroundColor: '#E05252', borderRadius: colors.radius, padding: 14, marginBottom: 14,
                    flexDirection: rowDir, alignItems: 'center', gap: 12 },
    locationCard: { backgroundColor: colors.card, borderRadius: colors.radius, borderWidth: 1,
                    borderColor: colors.border, padding: 14, marginBottom: 12 },
    sectionLabel: { fontSize: 11, fontFamily: 'Inter_600SemiBold', color: colors.mutedForeground,
                    textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 8 },
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle} accessibilityRole="header">{t('resources.near_me')}</Text>
        <Text style={styles.headerSub}>{t('resources.search_tip')}</Text>
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">

        {/* 911 Emergency */}
        <Pressable style={styles.emergencyCard} onPress={callEmergency}
          accessibilityRole="button" accessibilityLabel="Call 911 — Emergency Services">
          <Feather name="alert-triangle" size={22} color="#FFFFFF" />
          <Text style={{ flex: 1, fontSize: 15, fontFamily: 'Inter_600SemiBold', color: '#FFFFFF' }}>
            {t('resources.emergency')}
          </Text>
          <Text style={{ fontSize: 22, fontFamily: 'Inter_700Bold', color: '#FFFFFF' }}>911</Text>
        </Pressable>

        {/* Location input */}
        <View style={styles.locationCard}>
          <View style={{ flexDirection: rowDir, alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <Text style={{ fontSize: 14, fontFamily: 'Inter_600SemiBold', color: colors.foreground }}>
              📍 {t('resources.find_near_you')}
            </Text>
            <View style={{ flexDirection: rowDir, alignItems: 'center', gap: 4, backgroundColor: colors.muted,
              borderRadius: 12, paddingHorizontal: 8, paddingVertical: 4 }}>
              <Feather name="database" size={10} color={colors.mutedForeground} />
              <Text style={{ fontSize: 10, fontFamily: 'Inter_500Medium', color: colors.mutedForeground }}>
                {t('resources.nearby.live_source')}
              </Text>
            </View>
          </View>

          {/* Use my location */}
          <Pressable
            style={{ flexDirection: rowDir, alignItems: 'center', justifyContent: 'center', gap: 8,
              backgroundColor: colors.primary, borderRadius: 10, paddingVertical: 12, marginBottom: 10,
              opacity: loading ? 0.6 : 1 }}
            onPress={useMyLocation} disabled={loading} accessibilityRole="button">
            {loading
              ? <ActivityIndicator size="small" color="#FFFFFF" />
              : <Feather name="navigation" size={16} color="#FFFFFF" />}
            <Text style={{ fontSize: 14, fontFamily: 'Inter_600SemiBold', color: '#FFFFFF' }}>
              {loading ? t('resources.nearby.searching') : t('resources.use_my_location')}
            </Text>
          </Pressable>

          <Text style={{ fontSize: 12, fontFamily: 'Inter_400Regular', color: colors.mutedForeground,
            textAlign: 'center', marginBottom: 10 }}>
            {t('resources.enter_city_zip')}
          </Text>

          {/* Address search */}
          <View style={{ flexDirection: rowDir, gap: 8 }}>
            <TextInput
              style={{ flex: 1, backgroundColor: colors.muted, borderRadius: 10, paddingHorizontal: 12,
                paddingVertical: 10, fontSize: 14, fontFamily: 'Inter_400Regular', color: colors.foreground,
                borderWidth: 1, borderColor: colors.border }}
              value={manualInput}
              onChangeText={setManualInput}
              placeholder={t('resources.enter_location')}
              placeholderTextColor={colors.mutedForeground}
              returnKeyType="search"
              onSubmitEditing={searchByAddress}
              editable={!loading}
            />
            <Pressable
              style={{ backgroundColor: colors.primary, borderRadius: 10, paddingHorizontal: 16,
                paddingVertical: 10, alignItems: 'center', justifyContent: 'center', opacity: loading ? 0.6 : 1 }}
              onPress={searchByAddress} disabled={loading} accessibilityRole="button">
              {loading
                ? <ActivityIndicator size="small" color="#FFFFFF" />
                : <Feather name="search" size={16} color="#FFFFFF" />}
            </Pressable>
          </View>
        </View>

        {/* Curated fallback banner */}
        {isCurated ? (
          <View style={{ backgroundColor: colors.primary + '10', borderRadius: colors.radius, padding: 12,
            borderWidth: 1, borderColor: colors.primary + '30', marginBottom: 12,
            flexDirection: rowDir, alignItems: 'flex-start', gap: 8 }}>
            <Feather name="info" size={14} color={colors.primary} style={{ marginTop: 1 }} />
            <Text style={{ flex: 1, fontSize: 12, fontFamily: 'Inter_400Regular',
              color: colors.mutedForeground, lineHeight: 17 }}>
              {t('resources.curated_fallback')}
            </Text>
          </View>
        ) : null}

        {/* Location name */}
        {searched && locationName ? (
          <Text style={{ fontSize: 12, fontFamily: 'Inter_400Regular', color: colors.mutedForeground, marginBottom: 10 }}>
            📍 {locationName}
          </Text>
        ) : null}

        {/* ── Radius filter ── */}
        {searched && allResults.length > 0 && (
          <View style={{ marginBottom: 12 }}>
            <Text style={styles.sectionLabel}>{t('resources.nearby.show_within')}</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={{ flexDirection: rowDir, gap: 6, paddingRight: 8 }}>
                {RADIUS_CHIPS.map((mi) => {
                  const active = radiusMiles === mi;
                  // Count that would be visible at this radius (regardless of type)
                  const count  = allResults.filter(r => r.dist <= mi).length;
                  return (
                    <Pressable key={mi}
                      onPress={() => { setRadiusMiles(mi); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
                      style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 1.5,
                        borderColor: active ? colors.primary : colors.border,
                        backgroundColor: active ? colors.primary + '14' : colors.muted,
                        flexDirection: rowDir, alignItems: 'center', gap: 5 }}
                      accessibilityRole="radio" accessibilityState={{ selected: active }}>
                      <Text style={{ fontSize: 13, fontFamily: active ? 'Inter_600SemiBold' : 'Inter_400Regular',
                        color: active ? colors.primary : colors.mutedForeground }}>
                        {mi} {t('resources.mi')}
                      </Text>
                      <Text style={{ fontSize: 11, fontFamily: 'Inter_500Medium',
                        color: active ? colors.primary : colors.mutedForeground, opacity: 0.75 }}>
                        ({count})
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </ScrollView>
          </View>
        )}

        {/* ── Type filter ── */}
        {searched && allResults.length > 0 && (
          <View style={{ marginBottom: 12 }}>
            <Text style={styles.sectionLabel}>{t('resources.filter_type')}</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={{ flexDirection: rowDir, gap: 6, paddingRight: 8 }}>
                {TYPE_FILTERS.map(({ key, labelKey, color }) => {
                  const active = activeType === key;
                  const chipColor = active ? color : colors.mutedForeground;
                  const countForChip = key === 'all'
                    ? withinRadius.length
                    : withinRadius.filter(r => r.category === key).length;
                  return (
                    <Pressable key={key}
                      onPress={() => { setActiveType(key); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
                      style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 1.5,
                        borderColor: active ? color : colors.border,
                        backgroundColor: active ? color + '18' : colors.muted,
                        flexDirection: rowDir, alignItems: 'center', gap: 5 }}
                      accessibilityRole="radio" accessibilityState={{ selected: active }}>
                      <Text style={{ fontSize: 13, fontFamily: active ? 'Inter_600SemiBold' : 'Inter_400Regular',
                        color: chipColor }}>
                        {t(labelKey as any)}
                      </Text>
                      <Text style={{ fontSize: 11, fontFamily: 'Inter_500Medium', color: chipColor, opacity: 0.75 }}>
                        ({countForChip})
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </ScrollView>
          </View>
        )}

        {/* Results count */}
        {searched && (
          <Text style={{ fontSize: 12, fontFamily: 'Inter_400Regular', color: colors.mutedForeground, marginBottom: 10 }}>
            {filtered.length === 0
              ? t('resources.nearby.no_results_radius')
              : `${filtered.length} ${t(filtered.length === 1 ? 'resources.result' : 'resources.results')} ${t('resources.within')} ${radiusMiles} ${t('resources.mi')}`}
          </Text>
        )}

        {/* Empty state */}
        {searched && filtered.length === 0 && (
          <View style={{ backgroundColor: colors.muted, borderRadius: colors.radius, padding: 16,
            borderWidth: 1, borderColor: colors.border, alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <Feather name="search" size={20} color={colors.mutedForeground} />
            <Text style={{ fontSize: 14, fontFamily: 'Inter_500Medium', color: colors.mutedForeground, textAlign: 'center' }}>
              {t('resources.nearby.no_resources').replace('{radius}', String(radiusMiles))}
            </Text>
            {withinRadius.length > 0 && activeType !== 'all' ? (
              <Pressable onPress={() => setActiveType('all')}
                style={{ backgroundColor: colors.primary + '14', borderRadius: 10, paddingVertical: 8, paddingHorizontal: 16 }}>
                <Text style={{ fontSize: 13, fontFamily: 'Inter_500Medium', color: colors.primary }}>
                  {t('resources.filter_all')}
                </Text>
              </Pressable>
            ) : (
              <Text style={{ fontSize: 13, fontFamily: 'Inter_400Regular', color: colors.mutedForeground, textAlign: 'center', lineHeight: 18 }}>
                {t('resources.osm_sparse')}
              </Text>
            )}
          </View>
        )}

        {/* Result cards */}
        {searched && filtered.map(item => (
          <LiveResultCard
            key={item.id}
            item={item}
            rowDir={rowDir}
            ratingData={ratings[item.id]}
            userRating={userRatings[item.id]}
            onRate={setRatingTarget}
          />
        ))}

        {/* Open in Google Maps */}
        {searched && userLat !== null && userLon !== null && (
          <Pressable
            style={({ pressed }) => ({
              flexDirection: rowDir, alignItems: 'center', justifyContent: 'center', gap: 8,
              marginTop: 12, backgroundColor: '#4285F4',
              borderRadius: colors.radius, paddingVertical: 13, paddingHorizontal: 16,
              opacity: pressed ? 0.85 : 1,
            })}
            onPress={() => {
              const q = encodeURIComponent(`legal aid near ${locationName || 'me'}`);
              Linking.openURL(`https://www.google.com/maps/search/${q}/@${userLat},${userLon},13z`);
            }}
            accessibilityRole="button">
            <Feather name="map" size={16} color="#FFFFFF" />
            <Text style={{ fontSize: 14, fontFamily: 'Inter_600SemiBold', color: '#FFFFFF' }}>
              {t('resources.maps_btn')}
            </Text>
          </Pressable>
        )}

        {/* Intro tip */}
        {!searched && !loading && (
          <View style={{ backgroundColor: colors.primary + '0F', borderRadius: colors.radius, padding: 14,
            borderWidth: 1, borderColor: colors.primary + '20', flexDirection: rowDir, gap: 10 }}>
            <Feather name="map" size={16} color={colors.primary} />
            <Text style={{ flex: 1, fontSize: 13, fontFamily: 'Inter_400Regular',
              color: colors.mutedForeground, lineHeight: 19 }}>
              {t('resources.search_tip')} {t('resources.nearby.osm_note')}
            </Text>
          </View>
        )}

      </ScrollView>

      {/* Rating modal — rendered outside scroll so it floats above everything */}
      {ratingTarget && (
        <RatingModal
          item={ratingTarget}
          onClose={() => setRatingTarget(null)}
          onSubmit={async (id, rating) => {
            setUserRatings((prev) => ({ ...prev, [id]: rating }));
            setRatingTarget(null);
            const apiBase = getApiBase();
            if (!apiBase) return;
            try {
              const res = await fetch(`${apiBase}/api/ratings`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ resourceId: id, rating }),
              });
              if (res.ok) {
                const data = (await res.json()) as { avg: number; count: number };
                setRatings((prev) => ({ ...prev, [id]: data }));
              }
            } catch {
              // silently ignore — user already saw their tap register
            }
          }}
        />
      )}
    </View>
  );
}
