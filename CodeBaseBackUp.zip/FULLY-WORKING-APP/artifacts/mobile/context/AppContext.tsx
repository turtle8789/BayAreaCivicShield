import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import { AppState, AppStateStatus } from 'react-native';
import { DEFAULT_LANGUAGE, Language, getLanguageByCode } from '@/constants/languages';
import { ForumPost, SEED_POSTS } from '@/constants/forum-data';
import { BackupSchedule, BackupTimeWindow, BACKUP_SCHEDULE_LABELS, isBackupDue, resolveScheduleOnHydration } from '@/utils/backupSchedule';
import { AUTO_BACKUP_FILENAME, writeSilentBackup } from '@/utils/silentBackup';

// ─── Encounter types ─────────────────────────────────────────────────────────

export type EncounterType =
  | 'traffic_stop'
  | 'arrest'
  | 'questioning'
  | 'citation'
  | 'search'
  | 'other';

export interface Encounter {
  id: string;
  date: string;
  type: EncounterType;
  location: string;
  officerInfo: string;
  description: string;
  outcome: string;
}

export const ENCOUNTER_TYPE_LABELS: Record<EncounterType, string> = {
  traffic_stop: 'Traffic Stop',
  arrest: 'Arrest',
  questioning: 'Questioning',
  citation: 'Citation / Ticket',
  search: 'Search',
  other: 'Other',
};

// ─── Saved Deadlines (from Document Analyzer → Dashboard) ─────────────────────

export interface SavedDeadline {
  id: string;
  text: string;
  source: string;
  savedAt: string;
  docText?: string; // original document text — for "View Case Details" navigation
}

// Re-export so callers that import from AppContext still work
export type { BackupSchedule, BackupTimeWindow } from '@/utils/backupSchedule';
export { BACKUP_SCHEDULE_LABELS, BACKUP_TIME_WINDOW_LABELS, isBackupDue } from '@/utils/backupSchedule';

// ─── Accessibility / Settings ─────────────────────────────────────────────────

export type FontSizeLevel = 'small' | 'medium' | 'large';

export const FONT_SCALE: Record<FontSizeLevel, number> = {
  small: 0.9,
  medium: 1.0,
  large: 1.2,
};

export const HIGH_CONTRAST_OVERRIDES = {
  background: '#000000',
  foreground: '#FFFFFF',
  text: '#FFFFFF',
  card: '#111111',
  cardForeground: '#FFFFFF',
  border: '#555555',
  input: '#555555',
  muted: '#1A1A1A',
  mutedForeground: '#AAAAAA',
};

// ─── Context types ────────────────────────────────────────────────────────────

interface AppContextValue {
  // Hydration
  hydrated: boolean;

  // App Lock (PIN)
  appLockEnabled: boolean;
  appPin: string;
  setAppLock: (enabled: boolean, pin: string) => Promise<void>;
  lockTimeout: number; // minutes; -1 = Never, 0 = Immediately
  setLockTimeout: (minutes: number) => Promise<void>;
  biometricUnlockEnabled: boolean;
  setBiometricUnlockEnabled: (enabled: boolean) => Promise<void>;

  // Auto-backup
  autoBackupEnabled: boolean; // derived: backupSchedule !== 'off'
  setAutoBackupEnabled: (enabled: boolean) => Promise<void>; // compat: toggles off/each
  lastAutoBackupAt: string | null; // ISO timestamp of last successful auto-backup
  backupSchedule: BackupSchedule;
  setBackupSchedule: (schedule: BackupSchedule) => Promise<void>;
  backupTimeWindow: BackupTimeWindow;
  setBackupTimeWindow: (window: BackupTimeWindow) => Promise<void>;
  /**
   * True when the backup schedule key was absent during hydration but an
   * auto-backup file was found on disk — indicating that storage was wiped
   * (e.g. during an app update) while a schedule was previously active.
   * Consumers should prompt the user to re-confirm their schedule.
   */
  backupScheduleLost: boolean;
  dismissBackupScheduleLost: () => void;

  // Language
  language: Language;
  setLanguage: (lang: Language) => Promise<void>;
  isRTL: boolean;

  // Encounters
  encounters: Encounter[];
  addEncounter: (encounter: Omit<Encounter, 'id'>) => Promise<void>;
  deleteEncounter: (id: string) => Promise<void>;
  importEncounters: (newEncounters: Encounter[], replace: boolean) => Promise<void>;

  // Translation
  translateText: (text: string, targetLang: string) => Promise<string>;
  isTranslating: boolean;

  // Saved deadlines (dashboard)
  savedDeadlines: SavedDeadline[];
  addDeadline: (text: string, source: string, docText?: string) => Promise<void>;
  removeDeadline: (id: string) => Promise<void>;
  clearDeadlines: () => Promise<void>;

  // Pending doc text — set before navigating to Docs so it pre-populates the analyzer
  pendingDocText: string | null;
  setPendingDocText: (text: string | null) => void;

  // Forum (community discussion board)
  forumPosts: ForumPost[];  // user-created posts only (seed posts come from constants)
  addForumPost: (data: Omit<ForumPost, 'id' | 'helpfulCount' | 'markedHelpful' | 'isUserPost' | 'replies'>) => Promise<void>;
  toggleForumHelpful: (postId: string) => void;

  // Accessibility
  fontSize: FontSizeLevel;
  setFontSize: (size: FontSizeLevel) => void;
  fs: (base: number) => number;
  highContrast: boolean;
  setHighContrast: (v: boolean) => void;

  // Tour
  tourCompleted: boolean;
  setTourCompleted: (v: boolean) => void;
}

// Exported so useColors can read highContrast without a circular-dep issue
export const AppContext = createContext<AppContextValue | null>(null);

const STORAGE_ENCOUNTERS       = 'civicshield_encounters';
const STORAGE_DEADLINES        = 'civicshield_deadlines';
const STORAGE_FONT_SIZE        = 'civicshield_fontsize';
const STORAGE_TOUR             = 'civicshield_tour_done';
const STORAGE_HIGH_CONTRAST    = 'civicshield_high_contrast';
const STORAGE_FORUM_POSTS      = 'civicshield_forum_posts';
const STORAGE_FORUM_HELPFUL    = 'civicshield_forum_helpful';
const STORAGE_LANGUAGE         = 'civicshield_language';
const STORAGE_APP_LOCK         = 'civicshield_app_lock';
const STORAGE_APP_PIN          = 'civicshield_app_pin';
const STORAGE_LOCK_TIMEOUT     = 'civicshield_lock_timeout';
const STORAGE_AUTO_BACKUP          = 'civicshield_auto_backup';
const STORAGE_LAST_AUTO_BACKUP     = 'civicshield_last_auto_backup';
const STORAGE_BACKUP_SCHEDULE      = 'civicshield_backup_schedule';
const STORAGE_BACKUP_TIME_WINDOW   = 'civicshield_backup_time_window';
const STORAGE_BIOMETRIC_UNLOCK     = 'civicshield_biometric_unlock';

// ─── Pure backup-schedule helpers (exported for unit-testing) ────────────────

/**
 * Returns true when a scheduled backup is overdue.
 * 'off' and 'each' are never due via the timer path.
 */
// ─── Translation via free MyMemory API ───────────────────────────────────────

async function translateWithMyMemory(text: string, targetLang: string): Promise<string> {
  if (!text.trim()) return '';
  const truncated = text.slice(0, 450);
  const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(truncated)}&langpair=auto|${targetLang}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = (await res.json()) as {
    responseData?: { translatedText?: string };
    responseStatus?: number;
  };
  if (data.responseStatus !== 200) throw new Error('Translation failed');
  return data.responseData?.translatedText ?? text;
}

// ─── Provider ─────────────────────────────────────────────────────────────────

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [hydrated, setHydrated]                          = useState(false);
  const [appLockEnabled, setAppLockEnabled]              = useState(false);
  const [appPin, setAppPinState]                         = useState('');
  const [lockTimeout, setLockTimeoutState]               = useState<number>(5); // default 5 min
  const [biometricUnlockEnabled, setBiometricUnlockState]= useState(true); // default enabled
  const [backupSchedule, setBackupScheduleState]         = useState<BackupSchedule>('off');
  const [backupTimeWindow, setBackupTimeWindowState]     = useState<BackupTimeWindow>('any');
  const [lastAutoBackupAt, setLastAutoBackupAt]  = useState<string | null>(null);
  const [backupScheduleLost, setBackupScheduleLost]      = useState(false);
  const [language, setLanguageState]             = useState<Language>(DEFAULT_LANGUAGE);
  const [encounters, setEncounters]           = useState<Encounter[]>([]);

  // Refs for the AppState foreground-check (avoids stale-closure issues in listener)
  const backupScheduleRef    = useRef<BackupSchedule>('off');
  const backupTimeWindowRef  = useRef<BackupTimeWindow>('any');
  const lastAutoBackupAtRef  = useRef<string | null>(null);
  const encountersRef        = useRef<Encounter[]>([]);
  useEffect(() => { backupScheduleRef.current   = backupSchedule;   }, [backupSchedule]);
  useEffect(() => { backupTimeWindowRef.current = backupTimeWindow; }, [backupTimeWindow]);
  useEffect(() => { lastAutoBackupAtRef.current = lastAutoBackupAt; }, [lastAutoBackupAt]);
  useEffect(() => { encountersRef.current       = encounters;       }, [encounters]);
  const [isTranslating, setIsTranslating]     = useState(false);
  const [savedDeadlines, setSavedDeadlines]   = useState<SavedDeadline[]>([]);
  const [forumPosts, setForumPosts]           = useState<ForumPost[]>([]);
  const [helpfulIds, setHelpfulIds]           = useState<Set<string>>(new Set());
  const [fontSize, setFontSizeState]          = useState<FontSizeLevel>('medium');
  const [highContrast, setHighContrastState]  = useState(false);
  const [tourCompleted, setTourCompletedState]= useState(false);
  const [pendingDocText, setPendingDocText]   = useState<string | null>(null);

  // ── Hydrate from AsyncStorage ─────────────────────────────────────────────
  useEffect(() => {
    // Run storage reads and file-existence check in parallel so neither blocks
    // the other during the cold-start hydration pass.
    const autoBackupFileUri =
      (FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? '') +
      AUTO_BACKUP_FILENAME;

    Promise.all([
      AsyncStorage.getItem(STORAGE_ENCOUNTERS),
      AsyncStorage.getItem(STORAGE_DEADLINES),
      AsyncStorage.getItem(STORAGE_FONT_SIZE),
      AsyncStorage.getItem(STORAGE_TOUR),
      AsyncStorage.getItem(STORAGE_HIGH_CONTRAST),
      AsyncStorage.getItem(STORAGE_FORUM_POSTS),
      AsyncStorage.getItem(STORAGE_FORUM_HELPFUL),
      AsyncStorage.getItem(STORAGE_LANGUAGE),
      AsyncStorage.getItem(STORAGE_APP_LOCK),
      AsyncStorage.getItem(STORAGE_APP_PIN),
      AsyncStorage.getItem(STORAGE_LOCK_TIMEOUT),
      AsyncStorage.getItem(STORAGE_BIOMETRIC_UNLOCK),
      AsyncStorage.getItem(STORAGE_AUTO_BACKUP),
      AsyncStorage.getItem(STORAGE_LAST_AUTO_BACKUP),
      AsyncStorage.getItem(STORAGE_BACKUP_SCHEDULE),
      AsyncStorage.getItem(STORAGE_BACKUP_TIME_WINDOW),
      // Check whether an auto-backup file already exists on disk. Used below to
      // detect a storage wipe that lost the schedule setting while leaving the
      // backup file intact (common on Android after an app update or storage clear).
      FileSystem.getInfoAsync(autoBackupFileUri).then((info) => info.exists).catch(() => false),
    ]).then(([enc, dead, font, tour, hc, forum, helpful, lang, lock, pin, timeout, bioUnlock, autoBak, lastBak, sched, timeWin, backupFileExists]) => {
      if (enc)      setEncounters(JSON.parse(enc) as Encounter[]);
      if (dead)     setSavedDeadlines(JSON.parse(dead) as SavedDeadline[]);
      if (font)     setFontSizeState(font as FontSizeLevel);
      if (tour)     setTourCompletedState(tour === 'true');
      if (hc)       setHighContrastState(hc === 'true');
      if (forum)    setForumPosts(JSON.parse(forum) as ForumPost[]);
      if (helpful)  setHelpfulIds(new Set(JSON.parse(helpful) as string[]));
      if (lang)     setLanguageState(getLanguageByCode(lang));
      if (lock)     setAppLockEnabled(lock === 'true');
      if (pin)      setAppPinState(pin);
      if (timeout)  setLockTimeoutState(Number(timeout));
      if (bioUnlock !== null) setBiometricUnlockState(bioUnlock !== 'false'); // default true
      if (lastBak)  setLastAutoBackupAt(lastBak);

      // ── Schedule hydration (covers normal, legacy-migration, storage-wipe, first-install) ──
      // resolveScheduleOnHydration is a pure function that handles all four cases in
      // one place so they can't drift out of sync.
      const schedResult = resolveScheduleOnHydration(
        sched as string | null,
        autoBak,
        backupFileExists as boolean,
      );
      setBackupScheduleState(schedResult.schedule);
      if (schedResult.scheduleLost) setBackupScheduleLost(true);

      if (timeWin) setBackupTimeWindowState(timeWin as BackupTimeWindow);
    }).catch(() => {}).finally(() => setHydrated(true));
  }, []);

  const setAppLock = useCallback(async (enabled: boolean, pin: string) => {
    setAppLockEnabled(enabled);
    setAppPinState(pin);
    await AsyncStorage.setItem(STORAGE_APP_LOCK, enabled ? 'true' : 'false');
    await AsyncStorage.setItem(STORAGE_APP_PIN, pin);
    // Clear any accumulated wrong-attempt counter and lockout expiry so a
    // freshly-set PIN always starts with zero failed attempts, AND so that
    // stale lockout data from a previous PIN can never immediately re-lock
    // the user after they disable and then re-enable App Lock.
    await AsyncStorage.multiRemove(['@pin_attempts', '@pin_locked_until']);
  }, []);

  const setLockTimeout = useCallback(async (minutes: number) => {
    setLockTimeoutState(minutes);
    await AsyncStorage.setItem(STORAGE_LOCK_TIMEOUT, String(minutes));
  }, []);

  const setBiometricUnlockEnabled = useCallback(async (enabled: boolean) => {
    setBiometricUnlockState(enabled);
    await AsyncStorage.setItem(STORAGE_BIOMETRIC_UNLOCK, enabled ? 'true' : 'false');
  }, []);

  // ── Silent backup (shared by 'each' trigger and foreground schedule check) ──
  const performSilentBackup = useCallback(async (encs: Encounter[]) => {
    try {
      const result = await writeSilentBackup(
        encs,
        {
          documentDirectory: FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? null,
          writeAsStringAsync: (uri, content) =>
            FileSystem.writeAsStringAsync(uri, content, { encoding: FileSystem.EncodingType.UTF8 }),
        },
      );
      setLastAutoBackupAt(result.exportedAt);
      await AsyncStorage.setItem(STORAGE_LAST_AUTO_BACKUP, result.exportedAt);
    } catch {
      // Silent — never interrupt the user's flow
    }
  }, []);

  // ── Backup schedule setter ────────────────────────────────────────────────
  const setBackupSchedule = useCallback(async (schedule: BackupSchedule) => {
    setBackupScheduleState(schedule);
    // Any explicit schedule selection clears the loss warning — the user has
    // acknowledged the situation whether they used the banner CTA or the row directly.
    setBackupScheduleLost(false);
    await AsyncStorage.setItem(STORAGE_BACKUP_SCHEDULE, schedule);
    // Keep legacy key in sync so old restore paths still work
    await AsyncStorage.setItem(STORAGE_AUTO_BACKUP, schedule !== 'off' ? 'true' : 'false');
  }, []);

  // ── Backup time-window setter ─────────────────────────────────────────────
  const setBackupTimeWindow = useCallback(async (window: BackupTimeWindow) => {
    setBackupTimeWindowState(window);
    await AsyncStorage.setItem(STORAGE_BACKUP_TIME_WINDOW, window);
  }, []);

  // Compat shim: keeps any existing callers that use the old boolean API working
  const setAutoBackupEnabled = useCallback(async (enabled: boolean) => {
    await setBackupSchedule(enabled ? 'each' : 'off');
  }, [setBackupSchedule]);

  // Dismiss the "schedule was lost" banner once the user has acknowledged it
  // or re-set their schedule via the picker.
  const dismissBackupScheduleLost = useCallback(() => {
    setBackupScheduleLost(false);
  }, []);

  // ── Scheduled backup: cold-start check (runs once after hydration) ──────
  useEffect(() => {
    if (!hydrated) return;
    // Refs are synced in earlier effects that run on the same render, so they
    // already hold the freshly-hydrated values when this effect executes.
    if (isBackupDue(backupScheduleRef.current, lastAutoBackupAtRef.current, Date.now(), backupTimeWindowRef.current)) {
      performSilentBackup(encountersRef.current);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, performSilentBackup]); // intentionally omit refs — they're always current

  // ── Foreground-check: trigger daily/weekly backup on app resume ───────────
  useEffect(() => {
    const handleAppStateChange = (state: AppStateStatus) => {
      if (state !== 'active') return;
      if (isBackupDue(backupScheduleRef.current, lastAutoBackupAtRef.current, Date.now(), backupTimeWindowRef.current)) {
        performSilentBackup(encountersRef.current);
      }
    };

    const sub = AppState.addEventListener('change', handleAppStateChange);
    return () => sub.remove();
  }, [performSilentBackup]);

  const setLanguage = useCallback(async (lang: Language) => {
    setLanguageState(lang);
    await AsyncStorage.setItem(STORAGE_LANGUAGE, lang.code);
  }, []);

  // ── Encounters ────────────────────────────────────────────────────────────
  const addEncounter = useCallback(async (data: Omit<Encounter, 'id'>) => {
    const enc: Encounter = {
      ...data,
      id: Date.now().toString() + Math.random().toString(36).slice(2, 8),
    };
    const updated = [enc, ...encounters];
    setEncounters(updated);
    await AsyncStorage.setItem(STORAGE_ENCOUNTERS, JSON.stringify(updated));

    // ── Auto-backup: silently write to document storage after each save ──
    if (backupSchedule === 'each') {
      await performSilentBackup(updated);
    }
  }, [encounters, backupSchedule, performSilentBackup]);

  const deleteEncounter = useCallback(async (id: string) => {
    const updated = encounters.filter((e) => e.id !== id);
    setEncounters(updated);
    await AsyncStorage.setItem(STORAGE_ENCOUNTERS, JSON.stringify(updated));
  }, [encounters]);

  const importEncounters = useCallback(async (newEncs: Encounter[], replace: boolean) => {
    const updated = replace
      ? newEncs
      : [...newEncs.filter((n) => !encounters.some((e) => e.id === n.id)), ...encounters];
    setEncounters(updated);
    await AsyncStorage.setItem(STORAGE_ENCOUNTERS, JSON.stringify(updated));
  }, [encounters]);

  // ── Translation ───────────────────────────────────────────────────────────
  const translateText = useCallback(async (text: string, targetLang: string): Promise<string> => {
    setIsTranslating(true);
    try {
      return await translateWithMyMemory(text, targetLang);
    } finally {
      setIsTranslating(false);
    }
  }, []);

  // ── Saved Deadlines ───────────────────────────────────────────────────────
  const addDeadline = useCallback(async (text: string, source: string, docText?: string) => {
    const item: SavedDeadline = {
      id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
      text: text.slice(0, 300),
      source,
      savedAt: new Date().toISOString(),
      docText: docText?.slice(0, 4000), // store up to 4000 chars of the original document
    };
    const updated = [item, ...savedDeadlines];
    setSavedDeadlines(updated);
    await AsyncStorage.setItem(STORAGE_DEADLINES, JSON.stringify(updated));
  }, [savedDeadlines]);

  const removeDeadline = useCallback(async (id: string) => {
    const updated = savedDeadlines.filter((d) => d.id !== id);
    setSavedDeadlines(updated);
    await AsyncStorage.setItem(STORAGE_DEADLINES, JSON.stringify(updated));
  }, [savedDeadlines]);

  const clearDeadlines = useCallback(async () => {
    setSavedDeadlines([]);
    await AsyncStorage.removeItem(STORAGE_DEADLINES);
  }, []);

  // ── Forum posts ───────────────────────────────────────────────────────────
  const addForumPost = useCallback(async (
    data: Omit<ForumPost, 'id' | 'helpfulCount' | 'markedHelpful' | 'isUserPost' | 'replies'>,
  ) => {
    const post: ForumPost = {
      ...data,
      id: `user_${Date.now()}`,
      helpfulCount: 0,
      markedHelpful: false,
      isUserPost: true,
      replies: [],
    };
    const updated = [post, ...forumPosts];
    setForumPosts(updated);
    await AsyncStorage.setItem(STORAGE_FORUM_POSTS, JSON.stringify(updated));
  }, [forumPosts]);

  // Toggle "helpful" for both seed posts and user posts (tracked by ID set)
  const toggleForumHelpful = useCallback((postId: string) => {
    const newIds = new Set(helpfulIds);
    if (newIds.has(postId)) {
      newIds.delete(postId);
    } else {
      newIds.add(postId);
    }
    setHelpfulIds(newIds);
    AsyncStorage.setItem(STORAGE_FORUM_HELPFUL, JSON.stringify([...newIds])).catch(() => {});

    // Also update count in user posts
    setForumPosts((prev) => {
      const updated = prev.map((p) =>
        p.id === postId
          ? { ...p, markedHelpful: !p.markedHelpful, helpfulCount: p.helpfulCount + (p.markedHelpful ? -1 : 1) }
          : p,
      );
      AsyncStorage.setItem(STORAGE_FORUM_POSTS, JSON.stringify(updated)).catch(() => {});
      return updated;
    });
  }, [helpfulIds]);

  // ── Accessibility ─────────────────────────────────────────────────────────
  const setFontSize = useCallback((size: FontSizeLevel) => {
    setFontSizeState(size);
    AsyncStorage.setItem(STORAGE_FONT_SIZE, size).catch(() => {});
  }, []);

  const fs = useCallback((base: number) => Math.round(base * FONT_SCALE[fontSize]), [fontSize]);

  const setHighContrast = useCallback((v: boolean) => {
    setHighContrastState(v);
    AsyncStorage.setItem(STORAGE_HIGH_CONTRAST, v ? 'true' : 'false').catch(() => {});
  }, []);

  // ── Tour ──────────────────────────────────────────────────────────────────
  const setTourCompleted = useCallback((v: boolean) => {
    setTourCompletedState(v);
    AsyncStorage.setItem(STORAGE_TOUR, v ? 'true' : 'false').catch(() => {});
  }, []);

  // Merge helpfulIds into seed posts so markedHelpful reflects persisted state
  const allForumPosts = forumPosts.map((p) => ({
    ...p,
    markedHelpful: helpfulIds.has(p.id),
  }));

  const isRTL = !!language.isRTL;

  return (
    <AppContext.Provider
      value={{
        hydrated,
        appLockEnabled, appPin, setAppLock,
        lockTimeout, setLockTimeout,
        biometricUnlockEnabled, setBiometricUnlockEnabled,
        autoBackupEnabled: backupSchedule !== 'off', setAutoBackupEnabled, lastAutoBackupAt,
        backupSchedule, setBackupSchedule,
        backupTimeWindow, setBackupTimeWindow,
        backupScheduleLost, dismissBackupScheduleLost,
        language, setLanguage, isRTL,
        encounters, addEncounter, deleteEncounter, importEncounters,
        translateText, isTranslating,
        savedDeadlines, addDeadline, removeDeadline, clearDeadlines,
        pendingDocText, setPendingDocText,
        forumPosts: allForumPosts, addForumPost, toggleForumHelpful,
        fontSize, setFontSize, fs,
        highContrast, setHighContrast,
        tourCompleted, setTourCompleted,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
