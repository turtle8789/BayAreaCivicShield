/**
 * StarDisplay — shows a 5-star rating with filled, half, and empty stars.
 * Uses FontAwesome "star" (filled) and "star-o" (outline) from @expo/vector-icons.
 * Half stars are rendered by clipping a filled star to its left half.
 */
import React from 'react';
import { Pressable, View } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

export const STAR_GOLD  = '#F5A623';
export const STAR_EMPTY = '#CCCCCC';

// ─── Single star segment ──────────────────────────────────────────────────────

function StarSegment({ fill, size }: { fill: number; size: number }) {
  // fill is 0–1 (fractional portion of that star that should be filled)
  if (fill >= 0.75) {
    return <FontAwesome name="star"   size={size} color={STAR_GOLD}  />;
  }
  if (fill < 0.25) {
    return <FontAwesome name="star-o" size={size} color={STAR_EMPTY} />;
  }
  // Half star: overlay the left 50% of a filled star on top of an empty star
  return (
    <View style={{ width: size, height: size }}>
      <FontAwesome
        name="star-o"
        size={size}
        color={STAR_EMPTY}
        style={{ position: 'absolute', top: 0, left: 0 }}
      />
      <View style={{ overflow: 'hidden', width: size * 0.5, position: 'absolute', top: 0, left: 0 }}>
        <FontAwesome name="star" size={size} color={STAR_GOLD} />
      </View>
    </View>
  );
}

// ─── Read-only star row ───────────────────────────────────────────────────────

interface StarDisplayProps {
  /** Float 0–5 */
  rating: number;
  size?: number;
}

export function StarDisplay({ rating, size = 14 }: StarDisplayProps) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 2 }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <StarSegment
          key={i}
          fill={Math.min(Math.max(rating - (i - 1), 0), 1)}
          size={size}
        />
      ))}
    </View>
  );
}

// ─── Tappable stars (for rating input) ───────────────────────────────────────

interface TappableStarsProps {
  selected: number;       // 0 = none selected yet
  onSelect: (v: number) => void;
  size?: number;
}

export function TappableStars({ selected, onSelect, size = 36 }: TappableStarsProps) {
  return (
    <View style={{ flexDirection: 'row', gap: 10, justifyContent: 'center' }}>
      {[1, 2, 3, 4, 5].map((v) => (
        <Pressable
          key={v}
          onPress={() => onSelect(v)}
          hitSlop={10}
          accessibilityRole="radio"
          accessibilityLabel={`${v} star${v !== 1 ? 's' : ''}`}
          accessibilityState={{ selected: v === selected }}
        >
          <FontAwesome
            name={v <= selected ? 'star' : 'star-o'}
            size={size}
            color={v <= selected ? STAR_GOLD : STAR_EMPTY}
          />
        </Pressable>
      ))}
    </View>
  );
}
