export interface HubResource {
  id: string;
  category: HubCategory;
  name: string;
  description: string;
  descriptions?: Record<string, string>;
  url: string;
  phone?: string;
  free: boolean;
  tags: string[];
}

export type HubCategory =
  | 'legal_aid'
  | 'civil_rights'
  | 'immigration'
  | 'housing'
  | 'employment'
  | 'lgbtq'
  | 'forums';

export const HUB_CATEGORIES: { value: HubCategory; label: string; labelKey: string; emoji: string; color: string }[] = [
  { value: 'legal_aid',    label: 'Free Legal Aid',    labelKey: 'hub.cat_legal_aid',    emoji: '⚖️', color: '#C97B8E' },
  { value: 'civil_rights', label: 'Civil Rights',      labelKey: 'hub.cat_civil_rights', emoji: '✊', color: '#C9A050' },
  { value: 'immigration',  label: 'Immigration',       labelKey: 'hub.cat_immigration',  emoji: '🌎', color: '#5A9E6F' },
  { value: 'housing',      label: 'Housing Rights',    labelKey: 'hub.cat_housing',      emoji: '🏠', color: '#6B8EC9' },
  { value: 'employment',   label: 'Employment Rights', labelKey: 'hub.cat_employment',   emoji: '💼', color: '#A07888' },
  { value: 'lgbtq',        label: 'LGBTQ+ Legal',      labelKey: 'hub.cat_lgbtq',        emoji: '🏳️‍🌈', color: '#9B7EC9' },
  { value: 'forums',       label: 'Community Forums',  labelKey: 'hub.cat_forums',       emoji: '💬', color: '#C97B8E' },
];

export const HUB_RESOURCES: HubResource[] = [
  // ── Free Legal Aid ─────────────────────────────────────────────────────────
  {
    id: 'lh1',
    category: 'legal_aid',
    name: 'LawHelp.org',
    description: 'Find free legal aid programs in your state. Covers civil legal issues including housing, family, benefits, and more.',
    descriptions: { es: 'Encuentra programas de asistencia legal gratuita en tu estado. Cubre asuntos civiles como vivienda, familia, beneficios y más.' },
    url: 'https://www.lawhelp.org',
    free: true,
    tags: ['legal aid', 'free lawyer', 'civil'],
  },
  {
    id: 'lh2',
    category: 'legal_aid',
    name: 'Legal Services Corporation',
    description: 'The largest provider of civil legal aid for low-income Americans. Locate your nearest office by ZIP code.',
    descriptions: { es: 'El mayor proveedor de asistencia legal civil para estadounidenses de bajos ingresos. Localiza tu oficina más cercana por código postal.' },
    url: 'https://www.lsc.gov/what-legal-aid/find-legal-aid',
    free: true,
    tags: ['legal aid', 'low income', 'free'],
  },
  {
    id: 'lh3',
    category: 'legal_aid',
    name: 'National Lawyers Guild',
    description: 'Progressive legal organization. Provides support for civil rights, protest, and police misconduct cases.',
    descriptions: { es: 'Organización legal progresista. Brinda apoyo en casos de derechos civiles, protestas y mala conducta policial.' },
    url: 'https://www.nlg.org',
    phone: '212-679-5100',
    free: true,
    tags: ['civil rights', 'protest', 'police'],
  },
  {
    id: 'lh4',
    category: 'legal_aid',
    name: 'Law School Clinics Finder',
    description: 'Law school clinics offer free legal services supervised by professors. Search by state and practice area.',
    descriptions: { es: 'Las clínicas de escuelas de derecho ofrecen servicios legales gratuitos supervisados por profesores. Busca por estado y área de práctica.' },
    url: 'https://www.americanbar.org/groups/legal_services/flh-home/flh-clinic-directory/',
    free: true,
    tags: ['clinic', 'student lawyer', 'free'],
  },
  // ── Civil Rights ────────────────────────────────────────────────────────────
  {
    id: 'cr1',
    category: 'civil_rights',
    name: 'ACLU — Know Your Rights',
    description: 'The ACLU\'s comprehensive know-your-rights guides for police encounters, immigration, free speech, and more.',
    descriptions: { es: 'Las guías completas de la ACLU sobre tus derechos en encuentros con la policía, inmigración, libertad de expresión y más.' },
    url: 'https://www.aclu.org/know-your-rights',
    free: true,
    tags: ['rights', 'police', 'free speech'],
  },
  {
    id: 'cr2',
    category: 'civil_rights',
    name: 'NAACP Legal Defense Fund',
    description: 'Racial justice through litigation, advocacy, and public education. File a complaint or find resources.',
    descriptions: { es: 'Justicia racial mediante litigios, defensa y educación pública. Presenta una queja o encuentra recursos.' },
    url: 'https://www.naacpldf.org',
    free: true,
    tags: ['racial justice', 'discrimination', 'civil rights'],
  },
  {
    id: 'cr3',
    category: 'civil_rights',
    name: 'ACLU Mobile Justice App',
    description: 'Record police interactions safely. Video uploads automatically if your phone is confiscated.',
    descriptions: { es: 'Graba encuentros con la policía de forma segura. El video se sube automáticamente si te confiscan el teléfono.' },
    url: 'https://www.aclu.org/issues/criminal-law-reform/reforming-police/aclu-apps-record-police-conduct',
    free: true,
    tags: ['record police', 'app', 'safety'],
  },
  {
    id: 'cr4',
    category: 'civil_rights',
    name: 'National Police Accountability Project',
    description: 'Connects victims of police misconduct with attorneys who specialize in civil rights cases.',
    descriptions: { es: 'Conecta a víctimas de mala conducta policial con abogados especializados en casos de derechos civiles.' },
    url: 'https://www.nlg-npap.org',
    free: true,
    tags: ['police misconduct', 'accountability', 'attorney'],
  },
  // ── Immigration ─────────────────────────────────────────────────────────────
  {
    id: 'im1',
    category: 'immigration',
    name: 'RAICES',
    description: 'Free and low-cost legal services for immigrants and refugees. Emergency family separation hotline available.',
    descriptions: { es: 'Servicios legales gratuitos y de bajo costo para inmigrantes y refugiados. Línea de emergencia para separación familiar disponible.' },
    url: 'https://www.raicestexas.org',
    phone: '210-222-0964',
    free: true,
    tags: ['immigration', 'deportation', 'asylum', 'family'],
  },
  {
    id: 'im2',
    category: 'immigration',
    name: 'National Immigration Law Center',
    description: 'Defends and advances the rights of low-income immigrants through litigation, policy, and education.',
    descriptions: { es: 'Defiende y promueve los derechos de los inmigrantes de bajos ingresos mediante litigios, políticas y educación.' },
    url: 'https://www.nilc.org',
    free: true,
    tags: ['immigration', 'policy', 'low income'],
  },
  {
    id: 'im3',
    category: 'immigration',
    name: 'Immigration Advocates Network',
    description: 'Find accredited immigration legal services near you. Search by state and language.',
    descriptions: { es: 'Encuentra servicios legales de inmigración acreditados cerca de ti. Busca por estado e idioma.' },
    url: 'https://www.immigrationadvocates.org/legaldirectory/',
    free: true,
    tags: ['immigration', 'legal directory', 'language'],
  },
  {
    id: 'im4',
    category: 'immigration',
    name: 'Know Your Rights at Checkpoints (ACLU)',
    description: 'Step-by-step guide on what to do at Border Patrol interior checkpoints and during ICE encounters.',
    descriptions: { es: 'Guía paso a paso sobre qué hacer en retenes de la Patrulla Fronteriza y durante encuentros con el ICE.' },
    url: 'https://www.aclu.org/know-your-rights/what-do-when-encountering-law-enforcement-immigration',
    free: true,
    tags: ['checkpoint', 'ICE', 'border patrol'],
  },
  // ── Housing ─────────────────────────────────────────────────────────────────
  {
    id: 'ho1',
    category: 'housing',
    name: 'National Housing Law Project',
    description: 'Advances housing justice through law, policy, and training. Focuses on low-income tenants.',
    descriptions: { es: 'Promueve la justicia en vivienda mediante leyes, políticas y capacitación. Se enfoca en inquilinos de bajos ingresos.' },
    url: 'https://www.nhlp.org',
    free: true,
    tags: ['housing', 'tenant', 'eviction'],
  },
  {
    id: 'ho2',
    category: 'housing',
    name: 'HUD — Find Rental Assistance',
    description: 'Official U.S. government portal to find emergency rental assistance, HUD offices, and housing counselors.',
    descriptions: { es: 'Portal oficial del gobierno de EE.UU. para encontrar asistencia de alquiler de emergencia, oficinas de HUD y consejeros de vivienda.' },
    url: 'https://www.hud.gov/topics/rental_assistance',
    free: true,
    tags: ['HUD', 'rental assistance', 'government'],
  },
  {
    id: 'ho3',
    category: 'housing',
    name: 'Tenants Together (CA)',
    description: 'California\'s statewide renters rights organization. Free hotline and tenant resources.',
    descriptions: { es: 'Organización estatal de derechos de inquilinos de California. Línea gratuita y recursos para arrendatarios.' },
    url: 'https://www.tenantstogether.org',
    phone: '888-495-8020',
    free: true,
    tags: ['california', 'tenant', 'hotline'],
  },
  {
    id: 'ho4',
    category: 'housing',
    name: 'Emergency Rental Assistance Finder',
    description: 'Consumer Financial Protection Bureau tool to find ERA programs in your area.',
    descriptions: { es: 'Herramienta del CFPB para encontrar programas de asistencia de alquiler de emergencia en tu área.' },
    url: 'https://www.consumerfinance.gov/coronavirus/mortgage-and-housing-assistance/renter-protections/find-help-with-rent-and-utilities/',
    free: true,
    tags: ['emergency', 'rent', 'utilities'],
  },
  // ── Employment ──────────────────────────────────────────────────────────────
  {
    id: 'em1',
    category: 'employment',
    name: 'Department of Labor — File a Wage Complaint',
    description: 'File a free, anonymous wage complaint with the WHD. Covers overtime, minimum wage, and more.',
    descriptions: { es: 'Presenta una queja de salario anónima y gratuita ante la WHD. Cubre horas extras, salario mínimo y más.' },
    url: 'https://www.dol.gov/agencies/whd/contact/complaints',
    free: true,
    tags: ['wage', 'overtime', 'complaint'],
  },
  {
    id: 'em2',
    category: 'employment',
    name: 'EEOC — File a Discrimination Charge',
    description: 'The EEOC enforces federal workplace discrimination laws. File a free charge online.',
    descriptions: { es: 'La EEOC hace cumplir las leyes federales contra la discriminación laboral. Presenta un cargo gratuito en línea.' },
    url: 'https://www.eeoc.gov/filing-charge-discrimination',
    free: true,
    tags: ['discrimination', 'workplace', 'EEOC'],
  },
  {
    id: 'em3',
    category: 'employment',
    name: 'National Employment Law Project',
    description: 'Research and advocacy for workers\' rights. Guides on gig work, wage theft, and retaliation.',
    descriptions: { es: 'Investigación y defensa de los derechos de los trabajadores. Guías sobre trabajo independiente, robo de salario y represalias.' },
    url: 'https://www.nelp.org',
    free: true,
    tags: ['gig economy', 'wage theft', 'retaliation'],
  },
  {
    id: 'em4',
    category: 'employment',
    name: 'Worker Center Network',
    description: 'Find a local worker center — organizations that provide support, education, and legal referrals for workers.',
    descriptions: { es: 'Encuentra un centro de trabajadores local: organizaciones que brindan apoyo, educación y referencias legales para trabajadores.' },
    url: 'https://www.workercenternetwork.org',
    free: true,
    tags: ['worker center', 'local', 'support'],
  },
  // ── LGBTQ+ ──────────────────────────────────────────────────────────────────
  {
    id: 'lq1',
    category: 'lgbtq',
    name: 'Lambda Legal',
    description: 'Pursues litigation, education, and policy work on behalf of LGBTQ+ people and those living with HIV.',
    descriptions: { es: 'Realiza litigios, educación y trabajo de políticas en nombre de personas LGBTQ+ y quienes viven con VIH.' },
    url: 'https://www.lambdalegal.org',
    phone: '212-809-8585',
    free: true,
    tags: ['LGBTQ', 'discrimination', 'litigation'],
  },
  {
    id: 'lq2',
    category: 'lgbtq',
    name: 'Transgender Law Center',
    description: 'Free legal information and referrals for transgender people facing discrimination, police encounters, or ID issues.',
    descriptions: { es: 'Información legal gratuita y referencias para personas transgénero que enfrentan discriminación, encuentros con la policía o problemas de identificación.' },
    url: 'https://transgenderlawcenter.org',
    free: true,
    tags: ['transgender', 'discrimination', 'ID'],
  },
  {
    id: 'lq3',
    category: 'lgbtq',
    name: 'National Center for Lesbian Rights',
    description: 'Legal representation and resources for the LGBTQ+ community, including family law and employment.',
    descriptions: { es: 'Representación legal y recursos para la comunidad LGBTQ+, incluyendo derecho de familia y empleo.' },
    url: 'https://www.nclrights.org',
    phone: '415-392-6257',
    free: true,
    tags: ['LGBTQ', 'family law', 'employment'],
  },
  // ── Community Forums ─────────────────────────────────────────────────────────
  {
    id: 'fo1',
    category: 'forums',
    name: 'r/legaladvice (Reddit)',
    description: 'Large online community where you can ask general legal questions and get responses from legal professionals.',
    descriptions: { es: 'Gran comunidad en línea donde puedes hacer preguntas legales generales y obtener respuestas de profesionales del derecho.' },
    url: 'https://www.reddit.com/r/legaladvice',
    free: true,
    tags: ['reddit', 'general', 'Q&A'],
  },
  {
    id: 'fo2',
    category: 'forums',
    name: 'r/immigration (Reddit)',
    description: 'Active community for immigration questions, visa issues, and sharing experiences.',
    descriptions: { es: 'Comunidad activa para preguntas de inmigración, problemas de visa y compartir experiencias.' },
    url: 'https://www.reddit.com/r/immigration',
    free: true,
    tags: ['reddit', 'immigration', 'visa'],
  },
  {
    id: 'fo3',
    category: 'forums',
    name: 'Avvo Legal Q&A',
    description: 'Ask a legal question and receive free answers from licensed attorneys.',
    descriptions: { es: 'Haz una pregunta legal y recibe respuestas gratuitas de abogados certificados.' },
    url: 'https://www.avvo.com/ask-a-lawyer',
    free: true,
    tags: ['attorney', 'Q&A', 'free answer'],
  },
  {
    id: 'fo4',
    category: 'forums',
    name: 'JustAnswer — Legal',
    description: 'Chat with verified lawyers. Free to ask; paid for detailed consultation.',
    descriptions: { es: 'Chatea con abogados verificados. Gratis para preguntar; pago para consulta detallada.' },
    url: 'https://www.justanswer.com/law',
    free: false,
    tags: ['lawyer chat', 'consultation'],
  },
];

export const HUB_DISCLAIMER =
  '⚠️ Disclaimer: Resource links are provided for informational purposes only. CivicShield Pro does not endorse or verify all content on external sites. Always confirm information directly with the organization. Not legal advice.';
